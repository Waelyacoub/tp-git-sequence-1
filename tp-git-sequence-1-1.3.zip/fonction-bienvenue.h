#ifndef FONCTION_BIENVENUE_H
#define FONCTION_BIENVENUE_H
void afficherBienvenue(int nbAffichage = 1);
#endif // FONCTION_BIENVENUE_H
