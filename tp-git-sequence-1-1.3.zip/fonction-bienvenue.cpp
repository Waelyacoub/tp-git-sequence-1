#include "fonction-bienvenue.h"
#include <iostream>
void afficherBienvenue(int nbAffichage)
{
for (int i = 0; i < nbAffichage; ++i) {
std::cout << "Bienvenue le monde !" << std::endl;
}
}
